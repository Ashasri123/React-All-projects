import React from "react";

import logo from "../../images/thumbnail_OSCE2.png";
import logo1 from "../../images/capgemini-logo.svg";

const Header = () => {
  return (
    <div className="jumbotron">
      <img src={logo} alt="osce2 logo" className="logo"></img>
      <img src={logo1} style={{ marginLeft: "50%" }} alt="capg logo"></img>
    </div>
  );
};

export default Header;
