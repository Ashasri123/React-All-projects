import React from "react";
import "./App.css";
import Header from "./Header/Header";
import HomePage from "./HomePage/HomePage";
import Codegen from "./Codegen/Codegen";
import { Route, Switch } from "react-router-dom";

function App() {
  return (
    <div>
      <Header />
      <Switch>
        <Route exact path="/" component={HomePage} />
        <Route path="/codegen" component={Codegen} />
        {/*<Route path="/courses" component={CoursesPage} />
        <Route component={PageNotFound} /> */}
      </Switch>
    </div>
  );
}

export default App;
