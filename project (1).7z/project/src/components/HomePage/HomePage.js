import React, { useState } from "react";
import { Link } from "react-router-dom";

import "./homepage.css";
import { Button } from "@material-ui/core";

function HomePage() {
  const [userData, setUserData] = useState({
    title: "",
    description: "",
    host: "",
    basePath: "",
    artifactType: "Artifact Type"
  });

  function handleChange(event) {
    const updatedUserData = {
      ...userData,
      [event.target.name]: event.target.value
    };
    setUserData(updatedUserData);
  }

  return (
    <div>
      <div className="" style={{ paddingTop: "0px" }}>
        <div className="container-fluid">
          <div className="display-4 text-center">
            <i>OSCE API Builder</i>
          </div>
        </div>
        <div className="container" style={{ width: "50%", padding: "2%" }}>
          <div
            className="card bg-light"
            style={{ borderRadius: "15px 80px 30px" }}
          >
            <article className="card-body mx-auto"></article>
            <form>
              <div className="form-group input-group ip">
                <input
                  type="text"
                  name="title"
                  value={userData.title}
                  onChange={handleChange}
                  className="form-control"
                  placeholder="Title"
                ></input>
              </div>

              <div className="form-group input-group ip">
                <input
                  type="text"
                  name="description"
                  value={userData.description}
                  onChange={handleChange}
                  className="form-control"
                  placeholder="Description"
                ></input>
              </div>

              <div className="form-group input-group ip">
                <input
                  type="text"
                  name="host"
                  value={userData.host}
                  onChange={handleChange}
                  className="form-control"
                  placeholder="Host"
                ></input>
              </div>

              <div className="form-group input-group ip">
                <input
                  type="text"
                  name="basePath"
                  value={userData.basePath}
                  onChange={handleChange}
                  className="form-control"
                  placeholder="Base Path"
                ></input>
              </div>

              <div className="form-group input-group ip">
                <select
                  className="form-control"
                  value={userData.artifactType}
                  onChange={handleChange}
                  name="artifactType"
                >
                  <option>Select Artifact Type</option>
                  <option value="YAML">YAML</option>
                  <option value="JSON">JSON</option>
                  <option value="XSD">XSD</option>
                </select>
              </div>

              <div align="center" style={{ paddingBottom: "5%" }}>
                <Button
                  component="label"
                  variant="contained"
                  color="primary"
                  size="large"
                >
                  {"Choose Schema"}
                  <input type="file" style={{ display: "none" }} />
                </Button>
              </div>
            </form>
          </div>

          <div align="center" style={{ paddingTop: "5%" }}>
            <Link to="/codegen">
              <button type="button" className="generate">
                <span>Generate Artifacts</span>
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
