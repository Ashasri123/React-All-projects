import React from "react";
import { Link } from "react-router-dom";
function Codegen() {
  return (
    <div className="conatiner-fluid text-center">
      <div className="display-4">This page is for codegen</div>
      <br></br>

      <div className="row">
        <div className="col-md-2 offset-md-4">
          <Link to="/">
            <button className="btn btn-warning btn-block">Back</button>
          </Link>
        </div>
        <div className="col-md-2">
          <button className="btn btn-success btn-block">Generate Code</button>
        </div>
      </div>
    </div>
  );
}

export default Codegen;
