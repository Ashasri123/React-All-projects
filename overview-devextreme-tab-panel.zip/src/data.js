export const multiViewItems = [
  {
    ID: 1,
    CompanyName: "SuprMart",
    Address: "702 SW 8th Street",
    City: "Bentonville",
    State: "Arkansas",
    Zipcode: 72716,
    Phone: "(800) 555-2797",
    Fax: "(800) 555-2171",
    Website: "http://www.nowebsitesupermart.com"
  },
  {
    ID: 2,
    CompanyName: "El'Depot",
    Address: "2455 Paces Ferry Road NW",
    City: "Atlanta",
    State: "Georgia",
    Zipcode: 30339,
    Phone: "(800) 595-3232",
    Fax: "(800) 595-3231",
    Website: "http://www.nowebsitedepot.com"
  }
];
