import React, { Component } from 'react';
import axios from 'axios';
import {withRouter} from 'react-router-dom'
import createHistory from 'history/createBrowserHistory';

const history = createHistory();
 class Event extends Component {
    constructor() {
        super();
        this.serviceUrl = "http://localhost:5000/api/event";
        this.state = {
            event: [],
            user:[],
            post:[]
        }
    }
    componentDidMount() {
        axios.get(this.serviceUrl).then((res) => {
            this.setState({ event: res.data });
        })
    }
    onChanged=(event)=>{
        this.setState({[event.target.name]:event.target.value})
    }
    addpost=(eventname, start, end, image, location, adultprice, childprice, food, drinks, description)=>{
        //alert(job_position, company_name, job_description, employment_type, location, qualification, salary, experience, image);
        let newPost=[...this.state.post];
        let newpost={
            eventname:eventname,
            start:start,
            end:end, 
            image:image, 
            location:location, 
            adultprice:adultprice, 
            childprice:childprice, 
            food:food, 
            drinks:drinks, 
            description:description
        }
        axios.post(this.serviceUrl, newpost).then((res)=>{
            newPost.push(newpost);
            this.setState({post:newPost});
        })
    }

    showpost = () => {
        this.props.history.push('/addevent');
    }
    render() {
       
        return (<div>
            
           
        <button className="btn btn-default" onClick={(_id)=>this.showpost()}>Post</button>
        <br/><br/>
       
            
             
            
            
            
        </div>
        );
    }
}
export default withRouter(Job)
onSubmit = (event) => {
    event.preventDefault();
    console.log(this.state);
    
    const err = this.validate();
    if (!err) {
        // clear form
        this.setState({
            post:[],
            eventname: ' ',
            start: ' ',
            end:'',
            image:'',
            location:'',
            adultprice:'',
            childprice:'',
            food:'',
            drinks:'',
            description: ''
        });