import React, { Component } from 'react';
import axios from 'axios';

class EventDetails extends Component {
   constructor() {
      super();
      this.serviceUrl = "http://localhost:5000/api/event/";
      this.state = {
         event: [ ],
         user:[]

      }
   }
  
   componentDidMount() {
      let _id = this.props.match.params._id;
      axios.get(this.serviceUrl + _id).then((res) => {
         this.setState({
            event: res.data
         })
      })
   }
   
   apply = () => {
      this.props.history.push('/eventregistration/');
  }
   render() {
    
      return (
         <div>
            <div className="well">
            <img src={this.state.event.image} alt="" width="100" height="100"/>
            <h3>{this.state.event.eventname}</h3>
            <h3>{this.state.event.start}</h3>
            <h3>{this.state.event.end}</h3>
            <button className="btn btn-success" onClick={(_id)=>this.apply()}>Register</button>
            </div>
            <div className="well">
            <h3>Event Description:</h3>{this.state.event.description}
            <h3>Location:</h3><p>{this.state.event.location}</p>
            <h3>Price for Adult:</h3><p>{this.state.event.adultprice}</p>
            <h3>Price for Child:</h3><p>{this.state.event.childprice}</p>
            <h3>Food</h3><p>{this.state.event.food}</p>
            <h3>drinks</h3><p>{this.state.event.drinks}</p>
            </div>
            
         </div>
      );
   }
}
export default EventDetails;