import React, { Component } from 'react';
class EditEvent extends Component {
    state = {  }
    render() { 
        return ( 
            <div>
                <p>edit Component</p>
            </div>
         );
    }
}
 
export default EditEvent;