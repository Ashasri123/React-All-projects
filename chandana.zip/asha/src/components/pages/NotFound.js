import React from 'react';

const NotFound=()=> {
        return(
            
               <div>
                   <h1 className="text-danger">404<span>Error page not found</span></h1>
                   <p>Sorry page does not exist</p>
               </div>
            
        )
}

export default NotFound ;